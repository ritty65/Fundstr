import{q as a,aS as r}from"./index-Ccm2Oz49.js";function u(){return a(r)}export{u};
