import{l as a,A as s}from"./index-Ccm2Oz49.js";const p=a({name:"QSpace",setup(){const e=s("div",{class:"q-space"});return()=>e}});export{p as Q};
