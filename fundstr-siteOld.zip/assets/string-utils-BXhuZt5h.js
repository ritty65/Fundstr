function e(n,t=20,r=5){if(n.length>t+r)return n.substring(0,t)+"..."+n.substring(n.length-r,n.length)}export{e as s};
