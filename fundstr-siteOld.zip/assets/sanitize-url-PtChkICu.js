function n(t){try{const r=new URL(t,window.location.origin);return["http:","https:"].includes(r.protocol)}catch{return!1}}export{n as i};
