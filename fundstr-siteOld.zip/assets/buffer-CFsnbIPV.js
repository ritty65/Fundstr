import{a as f}from"./index-Ccm2Oz49.js";typeof globalThis<"u"&&typeof globalThis.Buffer>"u"&&(globalThis.Buffer=f.Buffer);
